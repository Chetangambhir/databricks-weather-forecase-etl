# One-notebook DAB deployment inside Databricks

This package contains exactly one executable notebook: an unchanged byte-for-byte copy of your attached 01_Weather_Pipeline.ipynb. It deploys one serverless notebook task as one job. Your dashboard remains a separate workspace dashboard using the existing Gold/audit tables. There is no second dashboard-setup task, validation task or dashboard asset in this bundle.

## Prepare the workspace folder
1. In Workspace > your user folder create weather-single-notebook, with a src subfolder.
2. Import the supplied notebook into src. Upload databricks.yml to the parent as a normal YAML workspace file. Keep README as an optional normal file. Do not import the ZIP as a notebook. Source filenames can lose .ipynb during workspace import; verify using the terminal before deployment.
3. Open this notebook and connect it to serverless compute. Open the terminal icon near the bottom of its right sidebar, or attached-compute dropdown > Web Terminal. The terminal must be available/enabled in your workspace. Serverless environment version 1 does not support it; select a newer available notebook environment if needed. Free Edition feature access is subject to account rollout and restrictions. If the terminal is absent, workspace-CLI instructions cannot be executed until it is available; do not substitute a fake terminal or claim deployment occurred.

## CLI from the web terminal
The built-in CLI authenticates as your current user. Do not install the old pip databricks-cli, run auth login, add --profile, or place access tokens in cells.

```bash
databricks version
databricks current-user me
cd "/Workspace/Users/YOUR_EMAIL/weather-single-notebook"
ls
ls src
```

Use your actual workspace folder path (Copy path in its menu). Check notebook_path in databricks.yml: it must match the source name recognized by the CLI. If the imported notebook appears extensionless, set it to ./src/01_Weather_Pipeline. If import stores it in another supported format, match that actual filename. Do not point it at a .bundle deployment copy.

Set catalog to the name printed by the notebook's parameter cell, then run:

```bash
databricks bundle validate -t dev --var catalog=YOUR_CATALOG
databricks bundle deploy -t dev --var catalog=YOUR_CATALOG
databricks bundle summary -t dev --var catalog=YOUR_CATALOG
databricks bundle run weather_pipeline -t dev --var catalog=YOUR_CATALOG
```

Run from the folder containing databricks.yml. Deployment uploads the source and creates/updates the job, but does not ingest weather. The run command executes it. No cluster definition means a serverless notebook task. If workspace-file CLI access is unsupported or validate cannot find the notebook, use the private Git-folder route below, or the local CLI fallback.

## Verify and show the dashboard
- In Jobs & Pipelines, find the deployed single-notebook job; development mode may prefix its name. Inspect its run and task output.
- A complete three-day clean run accepts 360 hourly rows for the original five cities. Confirm your actual audit results, plus no duplicate Silver/Gold business keys.
- Existing Gold, audit tables and monitoring views are created by this notebook. Its dashboard query cell prints ten datasets. Create your dashboard directly from those SQL queries; no added notebook is required. Refresh the dashboard after a run.
- A live FAILED or PARTIAL_SUCCESS outcome raises at the final cell and marks the task failed. Demo location failures are expected, audited, and do not mark the notebook task failed.
- max_concurrent_runs=1 covers this job, not simultaneous manual notebook execution. Do not run competing writers against the same mode.

## Failure runs
For a controlled failure run through the deployed job, use these SAME variables consistently:

```bash
databricks bundle validate -t dev --var catalog=YOUR_CATALOG,run_mode=demo,scenario=edge_mix,start_date=2030-01-01
databricks bundle deploy -t dev --var catalog=YOUR_CATALOG,run_mode=demo,scenario=edge_mix,start_date=2030-01-01
databricks bundle run weather_pipeline -t dev --var catalog=YOUR_CATALOG,run_mode=demo,scenario=edge_mix,start_date=2030-01-01
```

These update the same job. Use demo schemas/dashboard for fixtures. Restore live/none/blank-date defaults by deploying with only catalog before another live run. Do not use the fixed fixture date for live API calls. To trigger another scenario use retry_mix, structural_mix or bad_request in demo mode. No truncate/drop required.

## Private Git-folder route
The integrated workspace bundle editor requires a Git folder. Store these files in a private repository, clone through Workspace > Create > Git folder, then open its notebook's web terminal and cd to the actual Git-folder path containing databricks.yml. Run the same CLI commands above. This is optional for the direct CLI folder route, but required for the integrated bundle-editor workflow. Keep the assignment and solution private; no public repository or dashboard sharing.

## If web terminal is unavailable
Use the bundle editor Deploy UI in a Git folder if offered (this is UI deployment, not a CLI demonstration). For an actual CLI demonstration, use a local terminal with the current Databricks CLI:

```bash
databricks auth login --host https://YOUR_WORKSPACE_HOST --profile WEATHER
databricks bundle validate -t dev --profile WEATHER --var catalog=YOUR_CATALOG
databricks bundle deploy -t dev --profile WEATHER --var catalog=YOUR_CATALOG
databricks bundle run weather_pipeline -t dev --profile WEATHER --var catalog=YOUR_CATALOG
```

## Explain in the interview
"I package the existing notebook as a single serverless job using Declarative Automation Bundles. YAML defines the notebook path, execution parameters and concurrency. I validate, deploy and run through the CLI. The notebook builds Bronze, Silver, Gold and audit outputs; the dashboard queries those persisted outputs. Redeployment updates the job configuration, while keyed merges make data reruns safe."

No schedule is enabled. No automatic integration suite is enabled. No dashboard deployment is claimed. Locally checked: unchanged notebook bytes, notebook Python syntax, YAML/task/path structure, ZIP integrity. Workspace validate, deployment and execution require your session and have not been performed here.

Official documentation checked 13 October 2026:
- https://docs.databricks.com/aws/en/compute/web-terminal
- https://docs.databricks.com/aws/en/dev-tools/bundles/workspace
- https://docs.databricks.com/aws/en/dev-tools/bundles/examples

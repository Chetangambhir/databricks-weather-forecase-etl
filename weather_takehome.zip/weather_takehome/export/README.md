# Weather Pipeline Project

## Contents

### notebooks/
- `00_setup_checks.py` - Initial API connectivity and catalog checks
- `01_Weather_Pipeline.py` - Main weather ingestion pipeline (bronze -> silver -> gold)
- `02_Weather_Data_Validation.py` - SQL validation notebook for data quality checks

### dab/
- `databricks.yml` - Declarative Automation Bundle configuration
- `README.md` - DAB deployment instructions
- `src/01_Weather_Pipeline.py` - Notebook source for DAB deployment

### catalog/
- `01_create_tables.sql` - DDL for all Unity Catalog schemas and tables (live + demo)
- `02_seed_data.sql` - Seed data for config.locations (5 cities)

### dashboard/
- `Weather_Insights.lvdash.json` - Lakeview dashboard definition
- `dashboard_queries.sql` - SQL queries powering the dashboard datasets

## Architecture (Medallion)
- Config: 5 cities (Singapore, Delhi, Hyderabad, London, Sydney)
- Bronze: Raw API responses from Open-Meteo
- Silver: Validated hourly weather + quarantine
- Gold: Daily summaries with alerts (heat, wind, rain)
- Ops: Pipeline run tracking, API attempts, schema events

## Unity Catalog (workspace)
- weather_config, weather_bronze, weather_silver, weather_gold, weather_ops
- weather_demo_config, weather_demo_bronze, weather_demo_silver, weather_demo_gold, weather_demo_ops

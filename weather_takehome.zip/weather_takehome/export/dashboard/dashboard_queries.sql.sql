-- Databricks notebook source
-- Dashboard SQL queries for Weather Insights

-- Daily temperature
SELECT city_name, weather_date, avg_temperature_c, min_temperature_c, max_temperature_c
FROM `workspace`.`weather_gold`.`daily_weather_summary`
ORDER BY weather_date, city_name;

-- Daily precipitation
SELECT city_name, weather_date, total_precipitation_mm, is_complete_day
FROM `workspace`.`weather_gold`.`daily_weather_summary`
ORDER BY weather_date, city_name;

-- Weather alerts
SELECT city_name, weather_date, max_temperature_c, max_wind_speed_kmh,
       heat_alert, wind_alert, hours_available, is_complete_day
FROM `workspace`.`weather_gold`.`daily_weather_summary`
ORDER BY weather_date, city_name;

-- Latest run
SELECT status, duration_seconds, locations_succeeded, locations_failed,
       rows_received, rows_valid, rows_rejected, payloads_rejected,
       silver_rows_upserted, gold_rows_upserted
FROM `workspace`.`weather_ops`.v_latest_run;

-- Run history
SELECT started_at, status, scenario, duration_seconds, locations_succeeded,
       locations_failed, rows_valid, rows_rejected, payloads_rejected
FROM `workspace`.`weather_ops`.`pipeline_runs`
ORDER BY started_at DESC LIMIT 50;

-- Location health
SELECT * FROM `workspace`.`weather_ops`.v_location_health ORDER BY city_name;
